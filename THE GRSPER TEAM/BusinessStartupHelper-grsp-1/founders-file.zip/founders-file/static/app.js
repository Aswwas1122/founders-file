let state = { ideaName: '', ideaPrompt: '', round1: null, round2: null, round3: null };
const $ = (id) => document.getElementById(id);

document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.round-page').forEach(p => p.style.display = 'none');
    tab.classList.add('active');
    $('round' + tab.dataset.round).style.display = 'block';
    $('continueAnyway2').style.display = (tab.dataset.round === '2' && !state.round1) ? 'inline-block' : 'none';
    $('continueAnyway3').style.display = (tab.dataset.round === '3' && !state.round2) ? 'inline-block' : 'none';
  });
});

$('ideaName').addEventListener('input', (e) => { state.ideaName = e.target.value; });

function loadingHTML(msg) {
  return `<div class="loading-line"><span class="spinner"></span>${msg}</div>`;
}

function scoreStampClass(score) {
  if (score >= 65) return 'pos';
  if (score >= 40) return 'mid';
  return '';
}

function escapeHTML(s) {
  if (s === undefined || s === null) return '';
  return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

async function postJSON(url, body) {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

// ---- ROUND 1 ----
$('runAnalysis').addEventListener('click', async () => {
  const prompt = $('ideaPrompt').value.trim();
  if (!prompt) { $('ideaPrompt').focus(); return; }
  state.ideaPrompt = prompt;
  $('analysisResult').innerHTML = '';
  $('analysisLoading').style.display = 'block';
  $('analysisLoading').innerHTML = loadingHTML('Reading the market for this idea…');
  $('runAnalysis').disabled = true;

  try {
    const result = await postJSON('/api/analyze', { idea: prompt });
    state.round1 = result;
    renderRound1(result);
  } catch (err) {
    $('analysisResult').innerHTML = `<div class="empty-note">The analysis didn't come back (${err.message}). Check that the backend is running and ANTHROPIC_API_KEY is set, then try again.</div>`;
  } finally {
    $('analysisLoading').style.display = 'none';
    $('runAnalysis').disabled = false;
  }
});

function renderRound1(r) {
  const cls = scoreStampClass(r.score);
  $('analysisResult').innerHTML = `
    <div class="verdict">
      <div class="stamp ${cls}">
        <div class="score">${r.score}</div>
        <div class="of100">OUT OF 100</div>
      </div>
      <div class="verdict-text">
        <div class="call">${escapeHTML(r.verdict)}</div>
        <p>${escapeHTML(r.summary)}</p>
      </div>
    </div>
    <ul class="evidence-list">
      ${(r.positives || []).map(p => `<li><span class="tag">In favor</span>${escapeHTML(p)}</li>`).join('')}
      ${(r.risks || []).map(p => `<li class="risk"><span class="tag">Risk / open question</span>${escapeHTML(p)}</li>`).join('')}
    </ul>
  `;
  $('status1').classList.add('done');
  $('round2Gate').style.display = 'none';
  $('round2Body').style.display = 'block';
  $('continueAnyway2').style.display = 'none';
  updateExportVisibility();
}

// ---- ROUND 2 ----
$('continueAnyway2').addEventListener('click', () => {
  $('round2Gate').style.display = 'none';
  $('round2Body').style.display = 'block';
  $('continueAnyway2').style.display = 'none';
});

$('runModel').addEventListener('click', async () => {
  const notes = $('r2notes').value.trim();
  $('modelResult').innerHTML = '';
  $('modelLoading').style.display = 'block';
  $('modelLoading').innerHTML = loadingHTML('Sketching the model…');
  $('runModel').disabled = true;

  try {
    const result = await postJSON('/api/model', {
      idea: state.ideaPrompt || $('ideaName').value,
      round1: state.round1,
      notes,
    });
    state.round2 = result;
    renderRound2(result);
  } catch (err) {
    $('modelResult').innerHTML = `<div class="empty-note">The model didn't come back (${err.message}). Try again.</div>`;
  } finally {
    $('modelLoading').style.display = 'none';
    $('runModel').disabled = false;
  }
});

function renderRound2(m) {
  const allAmounts = [...(m.costBreakdown || []).map(x => x.amount), ...(m.revenueBreakdown || []).map(x => x.amount)];
  const maxAmt = Math.max(1, ...allAmounts);
  const flowRow = (label, amt, cls) => `
    <div class="flow-row">
      <div class="flow-label">${escapeHTML(label)}</div>
      <div class="flow-bar-track"><div class="flow-bar ${cls}" style="width:${Math.max(4, (amt / maxAmt * 100))}%"></div></div>
      <div class="flow-val">$${Number(amt).toLocaleString()}</div>
    </div>`;

  $('modelResult').innerHTML = `
    <div class="model-grid">
      <div class="model-card"><h3><span class="dot"></span>Customer</h3><p style="font-size:13.5px;line-height:1.55;margin:0;">${escapeHTML(m.customer)}</p></div>
      <div class="model-card"><h3><span class="dot"></span>Revenue model</h3><p style="font-size:13.5px;line-height:1.55;margin:0;">${escapeHTML(m.revenueModel)}</p></div>
      <div class="model-card" style="grid-column: 1 / -1;"><h3><span class="dot"></span>Why they choose this</h3><p style="font-size:13.5px;line-height:1.55;margin:0;">${escapeHTML(m.valueProp)}</p></div>
    </div>

    <div class="money-flow">
      <h3 style="font-size:14px;margin:0 0 14px;">Where the money goes in — and out</h3>
      ${(m.revenueBreakdown || []).map(x => flowRow(x.label, x.amount, '')).join('')}
      ${(m.revenueBreakdown || []).length && (m.costBreakdown || []).length ? '<div style="height:10px;"></div>' : ''}
      ${(m.costBreakdown || []).map(x => flowRow(x.label, x.amount, 'invest')).join('')}
      <div style="display:flex;justify-content:space-between;margin-top:14px;padding-top:12px;border-top:1px dashed var(--line);font-size:13px;">
        <span style="color:var(--ink-soft);">Total to launch</span>
        <span class="mono" style="font-weight:600;">$${Number(m.totalStartupInvestment || 0).toLocaleString()}</span>
      </div>
    </div>

    <div class="field" style="margin-top:20px;">
      <label>First milestone</label>
      <p style="font-size:13.5px;line-height:1.55;color:var(--ink-soft);margin:0;">${escapeHTML(m.firstMilestone)}</p>
    </div>
  `;
  $('status2').classList.add('done');
  $('round3Gate').style.display = 'none';
  $('round3Body').style.display = 'block';
  $('continueAnyway3').style.display = 'none';
  updateExportVisibility();
}

// ---- ROUND 3 ----
$('continueAnyway3').addEventListener('click', () => {
  $('round3Gate').style.display = 'none';
  $('round3Body').style.display = 'block';
  $('continueAnyway3').style.display = 'none';
});

$('runTax').addEventListener('click', async () => {
  $('taxResult').innerHTML = '';
  $('taxLoading').style.display = 'block';
  $('taxLoading').innerHTML = loadingHTML('Mapping this to Schedule C…');
  $('runTax').disabled = true;

  try {
    const result = await postJSON('/api/tax', {
      idea: state.ideaPrompt || $('ideaName').value,
      round2: state.round2,
    });
    state.round3 = result;
    renderRound3(result);
  } catch (err) {
    $('taxResult').innerHTML = `<div class="empty-note">The organizer didn't come back (${err.message}). Try again.</div>`;
  } finally {
    $('taxLoading').style.display = 'none';
    $('runTax').disabled = false;
  }
});

const ACCOUNTING_FIRMS = [
  { name: 'Bench', desc: 'Bookkeeping built for small businesses and freelancers, with optional tax filing add-on.' },
  { name: 'Block Advisors (H&R Block)', desc: 'Small-business-focused tax pros, in-person or virtual, comfortable with first-time Schedule C filers.' },
  { name: 'A local CPA who works with sole proprietors', desc: 'Often the best value once revenue is real — ask other small business owners in your area for a referral.' },
];

function renderRound3(t) {
  $('taxResult').innerHTML = `
    <div class="field"><label>Business structure, for now</label><p style="font-size:13.5px;line-height:1.6;color:var(--ink-soft);margin:0;">${escapeHTML(t.structureNote)}</p></div>

    <h3 style="font-size:14px;margin:22px 0 4px;">Deductions to track on Schedule C</h3>
    <table class="deduction-table">
      <thead><tr><th>Line</th><th>Category</th><th>Note</th></tr></thead>
      <tbody>${(t.deductions || []).map(d => `<tr><td class="line">${escapeHTML(d.line)}</td><td>${escapeHTML(d.category)}</td><td>${escapeHTML(d.note)}</td></tr>`).join('')}</tbody>
    </table>

    <div class="field" style="margin-top:22px;"><label>Quarterly taxes & self-employment tax</label><p style="font-size:13.5px;line-height:1.6;color:var(--ink-soft);margin:0;">${escapeHTML(t.quarterlyNote)}</p></div>

    <div class="field">
      <label>Recordkeeping habits to start now</label>
      <ul class="evidence-list">${(t.recordkeeping || []).map(r => `<li><span class="tag">Habit</span>${escapeHTML(r)}</li>`).join('')}</ul>
    </div>

    <div class="field"><label>When to bring in a real accountant</label><p style="font-size:13.5px;line-height:1.6;color:var(--ink-soft);margin:0;">${escapeHTML(t.whenToHireAccountant)}</p></div>

    <h3 style="font-size:14px;margin:22px 0 10px;">Firms that work with small businesses</h3>
    ${ACCOUNTING_FIRMS.map(f => `<div class="firm-card"><div class="name">${escapeHTML(f.name)}</div><div class="desc">${escapeHTML(f.desc)}</div></div>`).join('')}
  `;
  $('status3').classList.add('done');
  updateExportVisibility();
}

function updateExportVisibility() {
  $('exportBtn').style.display = (state.round1 || state.round2 || state.round3) ? 'inline-block' : 'none';
}

// ---- export ----
$('exportBtn').addEventListener('click', () => {
  const name = state.ideaName || $('ideaName').value || 'Untitled venture';
  let md = `# ${name}\n\n`;
  if (state.round1) {
    md += `## Round 1 — Should I do this?\n\n**Idea:** ${state.ideaPrompt}\n\n**Score:** ${state.round1.score}/100 — ${state.round1.verdict}\n\n${state.round1.summary}\n\n**In favor:**\n${(state.round1.positives || []).map(p => '- ' + p).join('\n')}\n\n**Risks:**\n${(state.round1.risks || []).map(p => '- ' + p).join('\n')}\n\n`;
  }
  if (state.round2) {
    md += `## Round 2 — Business model\n\n**Customer:** ${state.round2.customer}\n\n**Revenue model:** ${state.round2.revenueModel}\n\n**Value proposition:** ${state.round2.valueProp}\n\n**Startup investment total:** $${Number(state.round2.totalStartupInvestment || 0).toLocaleString()}\n\n**First milestone:** ${state.round2.firstMilestone}\n\n`;
  }
  if (state.round3) {
    md += `## Round 3 — Tax & finance\n\n${state.round3.structureNote}\n\n**Schedule C deductions:**\n${(state.round3.deductions || []).map(d => `- ${d.line} — ${d.category}: ${d.note}`).join('\n')}\n\n${state.round3.quarterlyNote}\n\n**When to hire an accountant:** ${state.round3.whenToHireAccountant}\n\n`;
  }
  md += `\n---\n*Generated by The Founder's File. Not financial, legal, or tax advice — verify specifics with a CPA.*\n`;

  const blob = new Blob([md], { type: 'text/markdown' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = (name.replace(/[^a-z0-9]+/gi, '-').toLowerCase() || 'founders-file') + '.md';
  a.click();
  URL.revokeObjectURL(url);
});
