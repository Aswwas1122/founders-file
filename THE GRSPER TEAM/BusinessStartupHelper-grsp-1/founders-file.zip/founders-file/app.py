"""
The Founder's File — Business Startup Helper
Flask backend. Serves the frontend and proxies three AI-assisted endpoints
to the Anthropic API: /api/analyze, /api/model, /api/tax.

Setup:
    pip install -r requirements.txt
    export ANTHROPIC_API_KEY=sk-ant-...      (or put it in a .env file)
    python app.py
Then open http://localhost:5000
"""

import json
import os

from flask import Flask, render_template, request, jsonify
import anthropic

# Load a .env file if python-dotenv is installed (optional convenience)
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

app = Flask(__name__)

client = anthropic.Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY"))
MODEL = "claude-sonnet-4-6"


def ask_claude_json(system_prompt: str, user_content: str) -> dict:
    """Call the Anthropic API and parse a strict-JSON response."""
    response = client.messages.create(
        model=MODEL,
        max_tokens=1500,
        system=system_prompt,
        messages=[{"role": "user", "content": user_content}],
    )
    text = "".join(block.text for block in response.content if block.type == "text")
    text = text.strip()
    # Strip accidental markdown fences, just in case
    if text.startswith("```"):
        text = text.split("```")[1]
        if text.startswith("json"):
            text = text[4:]
    return json.loads(text.strip())


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/analyze", methods=["POST"])
def analyze():
    data = request.get_json(force=True)
    idea = (data.get("idea") or "").strip()
    if not idea:
        return jsonify({"error": "Missing idea"}), 400

    system_prompt = """You are a sober, evidence-minded market analyst helping someone decide whether a business idea is worth pursuing. Respond ONLY with strict JSON, no markdown fences, no preamble, matching exactly this shape:
{
  "score": <integer 0-100, where 0 is do not pursue and 100 is very strong signal>,
  "verdict": "<one short punchy phrase, e.g. 'Worth a pilot' or 'Wait and validate more' or 'Hard pass for now'>",
  "summary": "<2-3 sentences giving the overall read, grounded and specific to this idea, not generic>",
  "positives": ["<short factual-sounding point in favor>", "... 2-4 items"],
  "risks": ["<short factual-sounding risk or open question>", "... 2-4 items"],
  "customer": "<one sentence describing the likely first customer>",
  "revenueIdea": "<one sentence on the most plausible way this makes money>",
  "startupCost": "<a rough plain-language cost band to get this running, e.g. 'under $2,000' or '$10,000-$30,000'>"
}
Base the read on general, well-established market knowledge and reasonable judgment about the category — be specific to the idea given, not generic startup advice. Do not hedge excessively; give an actual call."""

    try:
        result = ask_claude_json(system_prompt, f"Business idea: {idea}")
        return jsonify(result)
    except Exception as exc:  # noqa: BLE001
        return jsonify({"error": str(exc)}), 500


@app.route("/api/model", methods=["POST"])
def model():
    data = request.get_json(force=True)
    idea = (data.get("idea") or "").strip()
    round1 = data.get("round1")
    notes = (data.get("notes") or "").strip()

    if round1:
        context = (
            f"Idea: {idea}\n"
            f"Prior read: score {round1.get('score')}/100 ({round1.get('verdict')}). "
            f"Likely customer: {round1.get('customer')}. "
            f"Revenue idea: {round1.get('revenueIdea')}. "
            f"Rough startup cost: {round1.get('startupCost')}."
        )
    else:
        context = f"Idea: {idea or 'not specified — infer a plausible small business from the notes below'}."

    system_prompt = """You help first-time founders sketch a one-page business model. Respond ONLY with strict JSON, no markdown fences, matching exactly this shape:
{
  "customer": "<2-3 sentences on who the customer is, specifically>",
  "revenueModel": "<2-3 sentences on how money is made — pricing structure, e.g. subscription, one-time, commission>",
  "valueProp": "<1-2 sentences on why this customer chooses this over the alternative>",
  "keyCosts": ["<short cost line item>", "... 3-5 items covering both one-time startup and recurring"],
  "costBreakdown": [ {"label": "<short cost category, <=18 chars>", "amount": <integer dollars, one-time startup investment for this category>} , ... 3-5 items ],
  "revenueBreakdown": [ {"label": "<short revenue stream name, <=18 chars>", "amount": <integer, relative weight or estimated monthly dollars>} , ... 1-4 items ],
  "totalStartupInvestment": <integer dollars, sum-ish of costBreakdown>,
  "firstMilestone": "<one sentence describing the first concrete proof-of-concept milestone to hit>"
}
Ground every number in realistic ranges for a small first-time business of this kind — don't inflate. Keep cost/revenue labels short since they render as bar chart labels."""

    try:
        result = ask_claude_json(
            system_prompt,
            f"{context}{(' Founder notes: ' + notes) if notes else ''}",
        )
        return jsonify(result)
    except Exception as exc:  # noqa: BLE001
        return jsonify({"error": str(exc)}), 500


@app.route("/api/tax", methods=["POST"])
def tax():
    data = request.get_json(force=True)
    idea = (data.get("idea") or "").strip()
    round2 = data.get("round2")

    parts = []
    if idea:
        parts.append(f"Idea: {idea}")
    if round2:
        parts.append(
            f"Revenue model: {round2.get('revenueModel')}\n"
            f"Key costs: {'; '.join(round2.get('keyCosts') or [])}\n"
            f"Startup investment: ${round2.get('totalStartupInvestment')}"
        )
    context = "\n".join(parts) or "General first-time small business, no specifics given."

    system_prompt = """You help a new sole proprietor understand Schedule C (Form 1040) and basic tax strategy for a small business in the US. Respond ONLY with strict JSON, no markdown fences, matching exactly this shape:
{
  "structureNote": "<2-3 sentences on sole proprietor vs LLC vs S-corp considerations for a business at this stage, general and cautious>",
  "deductions": [ {"line": "<Schedule C line reference, e.g. 'Line 8' or 'Line 18'>", "category": "<deduction category name>", "note": "<1 sentence on what qualifies and a common pitfall>"} , ... 5-8 items relevant to this specific business ],
  "quarterlyNote": "<2-3 sentences on estimated quarterly taxes and self-employment tax basics, general guidance>",
  "recordkeeping": ["<short concrete recordkeeping habit>", "... 3-4 items"],
  "whenToHireAccountant": "<2-3 sentences on the signals that mean this founder should stop DIYing taxes and hire a professional>"
}
Keep it educational and general — never claim to replace a CPA, and say so implicitly through cautious, non-definitive phrasing. Tailor deduction categories to the specific business described, don't just list generic ones."""

    try:
        result = ask_claude_json(system_prompt, context)
        return jsonify(result)
    except Exception as exc:  # noqa: BLE001
        return jsonify({"error": str(exc)}), 500


if __name__ == "__main__":
    app.run(debug=True, port=5000)
