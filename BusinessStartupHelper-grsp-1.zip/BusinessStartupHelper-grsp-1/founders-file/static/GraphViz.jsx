/*
 * Business > Visualization — React graph (v4).
 *
 * Same star topology and same CSS classes as before, so style.css needs no
 * changes. This pass fixes the fast-forward ("Simulate forever") button,
 * which had four separate problems:
 *
 *  1. STALE CLOSURE — the month counter froze and repeated.
 *     The setInterval callback closed over `months` from the render in which
 *     the click happened and never saw the months it appended. Once it hit
 *     the end it recomputed the SAME next month every tick: state ended up
 *     1,2,...,12,13,13,13,13,13 with identical values, while the label
 *     counted "Month 13 / 18". Both timers now read monthsRef/indexRef, and
 *     the next month number comes from `lastMonth.month + 1` rather than
 *     `months.length + 1`, so it can't repeat even if the array diverges.
 *
 *  2. IT EXTENDED RUNS THAT HAD ALREADY DIED.
 *     If the forecast halted on the stop-loss at month 3, fast-forward
 *     happily computed month 4 onward from a business that was already out
 *     of cash. The button is now disabled once a run has halted.
 *
 *  3. NO UPPER BOUND — unbounded array growth.
 *     A profitable business never hits the stop-loss, so the loop ran
 *     forever, appending a month object every 400ms until the tab died.
 *     Capped at MAX_FORECAST_MONTHS with a visible status message.
 *
 *  4. THE TWEEN COULD NEVER COMPLETE.
 *     TWEEN_MS was 450 but the fast-forward interval is 400ms, so every
 *     animation was cancelled before finishing. `fromRef` was only assigned
 *     on completion, so each tween restarted from the same stale value and
 *     the numbers visibly stuttered. The tween now (a) captures whatever is
 *     on screen when interrupted, and (b) uses a shorter duration while
 *     fast-forwarding so it actually lands between ticks.
 *
 * Integration is unchanged — visualization.js calls
 * window.mountGraphViz(containerEl, simulationResult, inputs).
 */

const { useState, useRef, useEffect, useCallback } = React;

function fmtMoney(n) {
  const v = Number.isFinite(n) ? n : 0;
  const sign = v < 0 ? '-' : '';
  return `${sign}$${Math.abs(Math.round(v)).toLocaleString()}`;
}

const NODE_POS = {
  revenue: { x: 90, y: 70 },
  fixed: { x: 90, y: 190 },
  variable: { x: 90, y: 310 },
  loan: { x: 90, y: 380 },
  hub: { x: 500, y: 210 },
};

const TWEEN_MS = 450;        // normal playback / scrubbing
const FAST_TWEEN_MS = 260;   // during fast-forward, must be < FAST_INTERVAL_MS
const PLAY_INTERVAL_MS = 600;
const FAST_INTERVAL_MS = 400;

// 50 years. Past this the numbers are meaningless anyway, and without a cap
// the months array grows until the tab runs out of memory.
const MAX_FORECAST_MONTHS = 600;

function easeOutCubic(t) {
  return 1 - Math.pow(1 - t, 3);
}

const TWEEN_FIELDS = [
  'revenue', 'fixedPortion', 'variablePortion', 'loanPayment',
  'businessCashBalance', 'personalCashBalance', 'netCashFlow',
];

/**
 * Returns a "displayed" month whose TWEEN_FIELDS animate toward the target's
 * values. Crucially, an interrupted tween hands off from what's currently on
 * screen, not from the last target that happened to finish animating.
 */
function useTweenedMonth(targetMonth, durationMs = TWEEN_MS) {
  const [displayed, setDisplayed] = useState(targetMonth);
  const frameRef = useRef(null);
  const fromRef = useRef(targetMonth);
  const onScreenRef = useRef(targetMonth);

  useEffect(() => {
    if (!targetMonth) return undefined;
    const from = fromRef.current || targetMonth;
    const to = targetMonth;
    const start = performance.now();
    const duration = Math.max(1, durationMs);

    if (frameRef.current) cancelAnimationFrame(frameRef.current);

    function tick(now) {
      const t = Math.min(1, (now - start) / duration);
      const eased = easeOutCubic(t);

      const next = { ...to };
      TWEEN_FIELDS.forEach((key) => {
        const a = from[key] ?? 0;
        const b = to[key] ?? 0;
        next[key] = a + (b - a) * eased;
      });

      onScreenRef.current = next;
      setDisplayed(next);

      if (t < 1) {
        frameRef.current = requestAnimationFrame(tick);
      } else {
        fromRef.current = to;
      }
    }

    frameRef.current = requestAnimationFrame(tick);

    return () => {
      if (frameRef.current) cancelAnimationFrame(frameRef.current);
      // Hand off from what's actually rendered so a fast sequence of month
      // changes reads as continuous motion instead of restarting each time.
      fromRef.current = onScreenRef.current || from;
    };
  }, [targetMonth, durationMs]);

  return displayed || targetMonth;
}

function StatusLine({ month, isLast, breakEvenMonth, haltedAtMonth, reachedCap }) {
  let text = '';
  if (isLast && haltedAtMonth) {
    text = `Halted — cash hit the stop-loss threshold at month ${haltedAtMonth}.`;
  } else if (isLast && reachedCap) {
    text = `Stopped at the ${MAX_FORECAST_MONTHS}-month projection limit (${Math.round(MAX_FORECAST_MONTHS / 12)} years).`;
  } else if (month.loanDefaulted) {
    text = `Loan payment missed this month — the business couldn't afford it. Unpaid interest is capitalizing onto the balance.`;
  } else if (breakEvenMonth && month.month >= breakEvenMonth) {
    text = `Past break-even (month ${breakEvenMonth}).`;
  }
  return <div className="graph-status">{text}</div>;
}

function GraphViz({ simulationResult, inputs }) {
  const [months, setMonths] = useState(simulationResult.months);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [simulatingForever, setSimulatingForever] = useState(false);
  const [haltedAtMonth, setHaltedAtMonth] = useState(simulationResult.haltedAtMonth);
  const [reachedCap, setReachedCap] = useState(false);

  const timerRef = useRef(null);
    const taxStateRef = useRef(
    window.cloneSimState
      ? window.cloneSimState(simulationResult.taxState)
      : { quarterTaxable: 0, pendingTaxPayment: 0, lossCarryforward: 0 }
  );

  // Refs mirror state so the interval callbacks always read the CURRENT
  // array and index instead of a stale closure from the click render.
  const monthsRef = useRef(simulationResult.months);
  const indexRef = useRef(0);
  useEffect(() => { monthsRef.current = months; }, [months]);
  useEffect(() => { indexRef.current = currentIndex; }, [currentIndex]);

  const baselineRevenue = simulationResult.baselineRevenue;
  const saturationFloor = simulationResult.saturationFloor;
  const breakEvenMonth = simulationResult.breakEvenMonth;

  const currentMonth = months[currentIndex];
  const displayed = useTweenedMonth(
    currentMonth,
    simulatingForever ? FAST_TWEEN_MS : TWEEN_MS
  );

  const goToIndex = useCallback((idx) => {
    indexRef.current = idx;
    setCurrentIndex(idx);
  }, []);

  const stopPlaying = useCallback(() => {
    setPlaying(false);
    setSimulatingForever(false);
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = null;
  }, []);

  useEffect(() => stopPlaying, [stopPlaying]); // clear timer on unmount

  const handleScrub = (e) => {
    stopPlaying();
    // The slider is indexed by POSITION, not by month number, so a capped or
    // partial run can't desynchronise the two.
    goToIndex(parseInt(e.target.value, 10));
  };

  const handlePlayClick = () => {
    if (playing) { stopPlaying(); return; }
    if (indexRef.current >= monthsRef.current.length - 1) goToIndex(0);

    setPlaying(true);
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      if (indexRef.current >= monthsRef.current.length - 1) {
        stopPlaying();
        return;
      }
      goToIndex(indexRef.current + 1);
    }, PLAY_INTERVAL_MS);
  };

  // Fast-forward is meaningless once the business is already out of cash.
  const canFastForward = !haltedAtMonth && !reachedCap;

  const handleForeverClick = () => {
    if (simulatingForever) { stopPlaying(); return; }
    if (!canFastForward) return;

    setPlaying(true);
    setSimulatingForever(true);
    if (timerRef.current) clearInterval(timerRef.current);

    timerRef.current = setInterval(() => {
      const all = monthsRef.current;
      const idx = indexRef.current;

      // Still inside what's already computed — behave like normal playback.
      if (idx < all.length - 1) {
        goToIndex(idx + 1);
        return;
      }

      if (all.length >= MAX_FORECAST_MONTHS) {
        setReachedCap(true);
        stopPlaying();
        return;
      }

      // Genuinely at the end — extend by one month. The month number comes
      // from the last month itself, never from array length.
      const lastMonth = all[all.length - 1];
      const monthData = { saturationFloor, settleOutstandingTax: false, prevStepsCrossed: lastMonth.stepsCrossed }

      const extended = [...all, monthData];
      monthsRef.current = extended; // sync NOW so the next tick sees it
      setMonths(extended);
      goToIndex(idx + 1);

      if (monthData.businessCashBalance <= (inputs.stopLossThreshold || 0)) {
        setHaltedAtMonth(monthData.month);
        // Defer so this render still shows the halting month.
        setTimeout(stopPlaying, 0);
      }
    }, FAST_INTERVAL_MS);
  };

  if (!currentMonth) return null;

  const p = NODE_POS;
  const isLast = currentIndex === months.length - 1;
  const label = `Month ${currentMonth.month} / ${months.length}${simulatingForever ? ' (running…)' : ''}`;

  let foreverLabel = '⏭ Simulate forever';
  if (simulatingForever) foreverLabel = '⏹ Stop';
  else if (haltedAtMonth) foreverLabel = '⏭ Halted';
  else if (reachedCap) foreverLabel = '⏭ Limit reached';

  return (
    <div>
      <svg viewBox="0 0 700 420" className="graph-svg">
        <Edge id="revenue" from={p.revenue} to={p.hub} value={displayed.revenue} />
        <Edge id="fixed" from={p.fixed} to={p.hub} value={displayed.fixedPortion} />
        <Edge id="variable" from={p.variable} to={p.hub} value={displayed.variablePortion} />
        <Edge
          id="loan"
          from={p.loan}
          to={p.hub}
          value={displayed.loanPayment}
          overrideLabel={currentMonth.loanDefaulted ? 'defaulted' : null}
        />

        <Node id="revenue" pos={p.revenue} label="Revenue" colorClass="node-revenue" value={displayed.revenue} />
        <Node id="fixed" pos={p.fixed} label="Fixed Expenses" colorClass="node-expense" value={displayed.fixedPortion} />
        <Node id="variable" pos={p.variable} label="Variable Expenses" colorClass="node-expense" value={displayed.variablePortion} />
        <Node
          id="loan"
          pos={p.loan}
          label="Loan Payment"
          colorClass="node-expense"
          value={displayed.loanPayment}
          suffix={currentMonth.loanDefaulted ? ' (missed)' : ''}
        />

        <g className="graph-node node-hub">
          <rect x={p.hub.x - 110} y={p.hub.y - 65} width="220" height="150" rx="14" />
          <text x={p.hub.x} y={p.hub.y - 38} className="graph-node-label">Central Hub</text>
          <text x={p.hub.x} y={p.hub.y - 16} className="graph-node-value">{fmtMoney(displayed.businessCashBalance)}</text>
          <text x={p.hub.x} y={p.hub.y + 4} className="graph-node-sublabel">Business cash balance</text>
          <text x={p.hub.x} y={p.hub.y + 24} className="graph-node-sub">{`Net: ${fmtMoney(displayed.netCashFlow)}/mo`}</text>
          <text x={p.hub.x} y={p.hub.y + 42} className="graph-node-sub">{`Personal: ${fmtMoney(displayed.personalCashBalance)}`}</text>
          <text x={p.hub.x} y={p.hub.y + 60} className="graph-node-sub">
            {currentMonth.taxPaid
              ? `Tax paid: ${fmtMoney(currentMonth.taxPaid)}`
              : `Reinvested: ${Math.round((currentMonth.reinvestShare ?? 1) * 100)}%`}
          </text>
        </g>
      </svg>

      <div className="graph-controls">
        <button className="ghost" onClick={handlePlayClick}>
          {playing ? '⏸ Pause' : '▶ Play'}
        </button>
        <button className="ghost" onClick={handleForeverClick} disabled={!canFastForward && !simulatingForever}>
          {foreverLabel}
        </button>
        <input
          type="range"
          min="0"
          max={Math.max(0, months.length - 1)}
          value={currentIndex}
          step="1"
          onChange={handleScrub}
        />
        <span className="graph-month-label">{label}</span>
      </div>

      <StatusLine
        month={currentMonth}
        isLast={isLast}
        breakEvenMonth={breakEvenMonth}
        haltedAtMonth={haltedAtMonth}
        reachedCap={reachedCap}
      />
    </div>
  );
}

function Node({ id, pos, label, colorClass, value, suffix = '' }) {
  return (
    <g className={`graph-node ${colorClass}`} data-node={id}>
      <rect x={pos.x - 85} y={pos.y - 32} width="170" height="64" rx="10" />
      <text x={pos.x} y={pos.y - 6} className="graph-node-label">{label}</text>
      <text x={pos.x} y={pos.y + 16} className="graph-node-value">{fmtMoney(value) + suffix}</text>
    </g>
  );
}

function Edge({ id, from, to, value, overrideLabel = null }) {
  return (
    <g className="graph-edge" data-edge={id}>
      <line x1={from.x + 85} y1={from.y} x2={to.x - 95} y2={to.y} />
      <text x={(from.x + to.x) / 2} y={(from.y + to.y) / 2 - 8} className="graph-edge-label">
        {overrideLabel ?? fmtMoney(value)}
      </text>
    </g>
  );
}

/*
 * Plain-JS-callable mount point. visualization.js is a classic script and so
 * can never contain JSX; all JSX (including the mount) lives in this file,
 * which is the one Babel compiles.
 *
 * The bumped `key` forces a full remount on every Confirm, so a fresh
 * simulation always starts clean at month 1 rather than keeping the previous
 * instance's useState.
 */
function mountGraphViz(containerEl, simulationResult, inputs) {
  if (!containerEl) return;
  if (!containerEl._graphVizRoot) {
    containerEl._graphVizRoot = ReactDOM.createRoot(containerEl);
    containerEl._graphVizRunId = 0;
  }
  containerEl._graphVizRunId += 1;
  containerEl._graphVizRoot.render(
    <GraphViz key={containerEl._graphVizRunId} simulationResult={simulationResult} inputs={inputs} />
  );
}

window.GraphViz = GraphViz;
window.mountGraphViz = mountGraphViz;